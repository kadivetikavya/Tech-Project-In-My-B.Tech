import math
#constants
Wu=16#intensity of load in KN/m
Le=8000#legth of the beam in mm
fy=415#yeild strength of steel in Mpa
b=300#width of beam in mm
d=500#depth of beam in mm
phi=8#dia of 2 legged vertical stirrups in mm
Tauc=0.59#shear resistance of concrete in N/mm**2

Vu=(Wu*Le)/2
print("design shear force is:",Vu,"N")
Tauv=Vu/(b*d)
print("nominal shear force is:",Tauv,"N")

if(Tauv<Tauc):
    Asv=(2*(3.141/4)*phi**2)
    S1=(0.87*fy*Asv)/(0.4*b)
    print("spacing of stirrups is:",S1,"mm")
    S2=0.75*d
    print("spacing of stirrups is:",S2,"mm")
    S3=300
    print("spacing of stirrups is:",S3,"mm")
    print(min(S1,S2,S3))
      
    x=round(min(S1,S2,S3))
    print(x)

else:
    print("design shear reinforcement")
    Vus=Vu-(Tauc*b*d)
    S1=(0.87*fy*Asv*d)/Vus
    print("spacing of stirrups is:",S1,"mm")
    S2=(0.87*fy*Asv)/(0.4*b)
    print("spacing of stirrups is:",S2,"mm")
    S3=0.75*d
    print("spacing of stirrups is:",S3,"mm")
    S4=300
    print("spacing of stirrups is:",S4,"mm")


    print(min(S1,S2,S3,S4))
      
    x=round(min(S1,S2,S3,S4))
    print(x)

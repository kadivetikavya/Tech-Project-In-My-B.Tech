import math
P=int(input("Enter column load:"))
fck=int(input("Enter characteristic strentgh of concrete:"))
fy=int(input("Enter yield strength of steel:"))
b=float(input("Enter width of column:"))
D=float(input("Enter overall depth of column:"))
SBC=int(input("Enter SBC of soil:"))
phi=int(input("Enter dia of bar:"))
Pt=float(input("Enter percentage of steel:"))
#size of footing
Sf=(P/10)
print("self weigth of footing:",Sf,"KN")
TL=(P+Sf)
print("total load on soil:",TL,"KN")
Af=(TL/SBC)
print("area of footing:",Af,"m**2")
B1=math.sqrt(Af)
B=round(B1,0)
print("size of square footing:",B,"m")

#upward soil pressure
Pu=(1.5*P)
print("factored load on soil:",Pu,"KN")
qu=Pu/(B*B)
print("soil pressure at ultimate load:",qu,"KN/m**2")

#depth of footing from BM
x=(B-b)**2
mu=qu*B*x/8
print("BM on footing:",mu,"KN-m")
y=0.138*fck*B*1000
d1=math.sqrt(mu*10**6/y)
print("effective depth:",d1,"mm")
d=int(input("Enter depth of footing:"))

#check for one way shear
z=(B-b)/2
Vu1=qu*B*(z-d)
print("factored shear force:",Vu1,"kN")
Tauv=Vu1*1000/((B*1000)*d*1000)
print("nominal shear stress:",Tauv,"N/mm**2")
Tauc=float(input("Enter shear strength of concrete:"))
if(Tauc>Tauv):
    print("safe with respect to one way shear")
else:
    print("unsafe with respect to one way shear")
#check for two way shear
p=4*((b*1000)+(d))
print("perimeter of critical section:",p,"mm")
A=p*d
print("area of critical section:",A,"mm**2")
Vu2=qu*(B*B-(b+(d/1000))*(b+(d/1000)))
print("two way shear:",Vu2,"KN")
Tau=(Vu2*1000/A)*(d/1000)
print("two way shear stress:",Tau,"N/mm**2")
Taup=0.25*math.sqrt(fck)
print("perimissible punching stress:",Taup,"KN/m**2")
if(Taup>Tau):
    print("it is safe with respect to two way shear")
else:
    print("it is unsafe with respect to two way shear")
#reinforcement
P=(0.87*fy*fy)/(fck*B*1000)
Q=-(0.87*fy*d)
R=mu*10**6
S=(Q**2)-(4*P*R)
T=S**0.5
if(S<0):
    print("imaginary roots")
else:
    Ast1=(-Q+T)/(2*P)
    Ast2=(-Q-T)/(2*P)
    print("Ast1:\t",Ast1)
    print("Ast2:\t",Ast2)
    print(min(Ast1,Ast2))
S1=((3.14/4)*phi**2)*((B*1000)/Ast2)
print("spacing of bars:",S1,"mm")
x=round(S1)
print(x)

#check for bearing pressure
Wd=2*2*(d/1000)+(b)
print("width of dispersion of load:",Wd,"m")
A1=Wd*Wd
print("supporting area of footing:",A1,"m**2")
A2=(b)*(b)
print("loaded area of column base:",A2,"m**2")
a=int(input("Enter a number to get square root of A1/A2:"))
PBS=0.45*fck*(a)
print("permissible bearing stress:",PBS,"N/mm**2")
ABP=Pu*1000/((b*1000)*(b*1000))
print("actual bearing pressure:",ABP,"N/mm**2")
if(ABP<PBS):
    print("it is safe with respect to bearing pressure")
else:
    print("it is unsafe with respect to bearing pressure")








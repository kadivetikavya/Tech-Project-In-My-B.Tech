import math
ly=int(input("Enter length along y direction:"))
lx=int(input("Enter length along x direction:"))
LL=int(input("Enter live load:"))
FF=int(input("Enter floor finish:"))
d1=int(input("Enter effective depth of slab:"))
D=int(input("Enter total depth of slab:"))
fck=int(input("Enter characteristic strentgh of concrete:"))
fy=int(input("Enter yield strength of steel:"))
phi1=int(input("Enter dia of bar1:"))
phi2=int(input("Enter dia of bar2:"))
alphax=float(input("Enter alphax value:"))
alphay=float(input("Enter alphay value:"))
rho=25#unit weight of rcc in KN/m^2
b=1000
#assume clear cover 25 in mm
#check for one way slab or two way slab
if(ly/lx)>2:
    print("the slab is to be designed as a one way slab")
else:
    print("the slab is to be designed as a two way slab")
#loads calculations    
SS=(D/1000)*rho
W=(SS+LL+FF) 
print("total load required is:",W,"KN/m^2")
Wu=1.5*W
print("factored load required is:",Wu,"KN/m^2")

#effective span
ly1=((ly/1000)+(d1/1000))
print("effective span required:",ly1,"m")
lx1=((lx/1000)+(d1/1000))
print("effective span required:",lx1,"m")
le=(ly1)/(lx1)
print("effective span required is:",le,"m")

#factored BM & SF
Mux=alphax*Wu*(lx1)**2
print("factored bending moment required is:",Mux,"KN*m")
Muy=alphay*Wu*(lx1)**2
print("factored bending moment required is:",Muy,"KN*m")
vu=((Wu*lx1)/2)
print("factored shear force required is:",vu,"KN")
#min depth required
d2=math.sqrt((Mux*10**6)/(0.138*fck*b))
print("min depth required is:",d2,"mm")
#tension reinforcement along x direction
P=(0.87*fy*fy)/(fck*b)
Q=-(0.87*fy*(d1))
R=Mux*10**6
S=(Q**2)-(4*P*R)
T=S**0.5
if(S<0):
    print("imaginary roots")
else:
    Astx1=(-Q+T)/(2*P)
    Astx2=(-Q-T)/(2*P)
    print("Astx1:\t",Astx1)
    print("Astx2:\t",Astx2)
    print(min(Astx1,Astx2))
Astmin=((0.12/100)*1000*D)    
print("area of steel min required is:",Astmin,"mm^2")
if(Astx2>Astmin):
    print("area of steel is:",Astx2,"mm^2")
else:
    print("minimum area of steel required:",Astmin,"mm^2")

#spacing of bars
ast1=(3.141/4)*phi1**2
s1=(ast1/Astx2)*1000
print("spacing required:",s1,"mm")
s2=3*d1
print("spacing required:",s2,"mm")
s3=300
print("spacing required:",s3,"mm")
print(min(s1,s2,s3))
      
x=round(min(s1,s2,s3))
print("round of spacing required is:",x,"mm")

#tension reinforcement along y
P=(0.87*fy*fy)/(fck*b)
Q=-(0.87*fy*(d1))
R=Muy*10**6
S=(Q**2)-(4*P*R)
T=S**0.5
if(S<0):
    print("imaginary roots")
else:
    Asty1=(-Q+T)/(2*P)
    Asty2=(-Q-T)/(2*P)
    print("Asty1:\t",Asty1)
    print("Asty2:\t",Asty2)
    print(min(Asty1,Asty2))
Astmin=((0.12/100)*1000*D)    
print("area of steel min required is:",Astmin,"mm^2")
if(Asty2>Astmin):
    print("area of steel is:",Asty2,"mm^2")
else:
    print("minimum area of steel required:",Astmin,"mm^2")

#spacing of bars
ast1=(3.141/4)*phi1**2
s4=(ast1/Asty2)*1000
print("spacing required:",s4,"mm")
s5=3*d1
print("spacing required:",s5,"mm")
s6=300
print("spacing required:",s6,"mm")
print(min(s4,s5,s6))
      
x=round(min(s4,s5,s6))
print("round of spacing required is:",x,"mm")

#reinforcement in edge strip
ast2=(3.141/4)*phi2**2
Ast=(0.12/100)*b*D
s4=(ast2/Astmin)*1000
print("spacing required:",s4,"mm")
s5=5*d1
print("spacing required:",s5,"mm")
s6=450
print("spacing required:",s6,"mm")
print(min(s4,s5,s6))
      
x=round(min(s4,s5,s6))
print("round of spacing required is:",x,"mm")

#torsion reinforecement
edge1="both ends discontinuous"
edge2="one edge continous other discontinuous"
edge3="both ends continous"
if edge1=="both ends discontinuous":
    print("both ends discontinuous")
    Ltr1=(lx1*1000)/5
    print("length of torsion reinfocemenet:",Ltr1,"mm")
    Atr1=3/4*(Astx2)
    print("area of torsion reinfocemenet:",Atr1,"mm**2")
    ast3=(3.141/4)*phi2**2
    s7=(ast3/Atr1)*1000
    print("spacing required:",s7,"mm")
    x=round(s7)
    print("round of spacing required is:",x,"mm")
elif edge2=="one edge continous other discontinuous":
    print("one edge continous other discontinuous")
    Ltr2=(lx1*1000)/5
    print("length of torsion reinfocemenet:",Ltr2,"mm")
    Atr2=3/8*(Astx2)
    print("area of torsion reinfocemenet:",Atr2,"mm**2")
    ast4=(3.141/4)*phi2**2
    s8=(ast4/Atr2)*1000
    print("spacing required:",s8,"mm")
    x=round(s8)
    print("round of spacing required is:",s8,"mm")
else:
    print("no need of torsional reinforcement")













    

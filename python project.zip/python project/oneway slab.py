import math
ly=int(input("Enter length along y direction:"))
lx=int(input("Enter length along x direction:"))
LL=int(input("Enter live load:"))
FF=int(input("Enter floor finish:"))
d1=int(input("Enter effective depth of slab:"))
D=int(input("Enter total depth of slab:"))
fck=int(input("Enter characteristic strentgh of concrete:"))
fy=int(input("Enter yield strength of steel:"))
L=int(input("Enter clear span:"))
t=int(input("Enter thickness of wall:"))
phi1=int(input("Enter dia of bar1:"))
phi2=int(input("Enter dia of bar2:"))
rho=25#unit weight of rcc in KN/m^2
b=1000
#assume clear cover 25 in mm
#check for one way slab or two way slab
if(ly/lx)>2:
    print("the slab is to be designed as a one way slab")
else:
    print("the slab is to be designed as a two way slab")
#loads calculations    
SS=(D/1000)*rho
W=(SS+LL+FF) 
print("total load required is:",W,"KN/m^2")
Wu=1.5*W
print("factored load required is:",Wu,"KN/m^2")
#effective span
le1=((L/1000)+(t/1000))
le2=((L/1000)+(d1/1000))
print("effective span required is:",le1,"m")
print("effective span required is:",le2,"m")
print(min(le1,le2))
#factored BM & SF
mu=((Wu)*((le2)**2)/8)
print("factored bending moment required is:",mu,"KN*m")
vu=((Wu)*(le2)/2)
print("factored shear force required is:",vu,"KN")
#min depth required
d2=math.sqrt((mu*10**6)/(0.138*fck*b))
print("min depth required is:",d2,"mm")

#tension reinforcement
P=(0.87*fy*fy)/(fck*b)
Q=-(0.87*fy*(d1))
R=mu*10**6
S=(Q**2)-(4*P*R)
T=S**0.5
if(S<0):
    print("imaginary roots")
else:
    Ast1=(-Q+T)/(2*P)
    Ast2=(-Q-T)/(2*P)
    print("Ast1:\t",Ast1)
    print("Ast2:\t",Ast2)
    print(min(Ast1,Ast2))
Astmin=((0.12/100)*1000*D)    
print("area of steel min required is:",Astmin,"mm^2")
if(Ast2>Astmin):
    print("area of steel is:",Ast2,"mm^2")
else:
    print("minimum area of steel required:",Astmin,"mm^2")

#spacing of bars
ast1=(3.141/4)*phi1**2
s1=(ast1/Ast2)*1000
print("spacing required:",s1,"mm")
s2=3*d1
print("spacing required:",s2,"mm")
s3=300
print("spacing required:",s3,"mm")
print(min(s1,s2,s3))
      
x=round(min(s1,s2,s3))
print("round of spacing required is:",x,"mm")

#distribution reinforcement
ast2=(3.141/4)*phi2**2
Ast=(0.12/100)*b*D
s4=(ast2/Astmin)*1000
print("spacing required:",s4,"mm")
s5=5*d1
print("spacing required:",s5,"mm")
s6=450
print("spacing required:",s6,"mm")
print(min(s4,s5,s6))
      
x=round(min(s4,s5,s6))
print("round of spacing required is:",x,"mm")

#check for shear
tauv=(vu*1000)/(b*d1)
print("nominal shear stress:",tauv,"N/mm**2")
tauc=0.28#shear strength of concrete for beam in N/mm**2
tauc=1.3*0.28
print("shear strength of concrete required is:",tauc,"N/mm**2")
if (tauv<tauc):
    print("the slab is safe in shear")
else:
    print("the slab is not-safe in shear")








import math
b=int(input("Enter width of column:"))
D=int(input("Enter overall depth of column:"))
fck=int(input("Enter characteristic strentgh of concrete:"))
fy=int(input("Enter yield strength of steel:"))
Pu=int(input("Enter factored load:"))
L=int(input("Enter unsupported length:"))
phi=int(input("Enter dia of bar:"))
le=0.65*L#effective length when coulmn is fixed both ends
if((le/b)<12):
    print("column is designed as short column")
else:
    print("column is designed as long column")
emin1=((L/500)+(D/30))
print("minimum eccentricy:",emin1,"mm")
emin2=20
print("minimum eccentricy:",emin2,"mm")
print(min(emin1,emin2))

emin3=(20/D)
print("minimum eccentricy:",emin3,"mm")
if(emin3<=0.05):
    print("designed as axially loaded column")
else:
    print("designed as uniaxial,biaxial column")

#Main reinforcemenet
Ag=b*D
print("gross area:",Ag,"mm**2")
Asc=((Pu-0.4*fck*Ag-0.4*fck)/(0.67*fy))
print("area of steel:",Asc,"mm**2")
Ac=Ag-Asc
print("area of concrete:",Ac,"mm**2")
Ascmin=((0.8/100)*Ag)
print("min area of steel:",Ascmin,"mm**2")
Ascmax=((0.6/100)*Ag)
print("max area of steel:",Ascmax,"mm**2")

if(Ascmin)<Asc<(Ascmax):
    print("area of steel:",Asc,"mm**2")
elif(Asc)<(Ascmin)<(Ascmax):
    print("area of steel:",Ascmin,"mm**2")
else:
    print("area of steel:",Ascmax,"mm**2")

#no of bars
ast=(3.14/4)*phi**2
N=(ast/Asc)
print("no of bars:",N)

#lateral ties
phi1=phi/4
phi2=6
print(max(phi1,phi2))
s1=(b)#least lateral dimension of column
print("spacing required:",s1,"mm")
s2=16*phi
print("spacing required:",s2,"mm")
s3=300
print("spacing required:",s3,"mm")
print(min(s1,s2,s3))
      
x=round(min(s1,s2,s3))
print("round of spacing required is:",x,"mm")
    




    

import math

#constants
fck=25#characteristic strength of concrete in Mpa
fy=int(input("Enter grade of steel:"))
b=300#width of beam in mm
d=500#depth of beam in mm
phi=16#dia of bar in mm
l=10000#length of beam in mm
w=16#intensity of load in N/mm
mu=(w*l**2)/8
Astmin=((0.85*b*d)/fy)
print(Astmin)
while True:
    fy=int(input("Enter grade of steel:"))
    if(fy==250):
        mulim=0.148*fck*b*d*d
        print("the limiting moment of resistance is:",mulim,"N.mm")
        if(mu<mulim):
            print("the structure is safe & it is under reinforced section")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:\t",Ast1)
                print("Ast2:\t",Ast2)
                print(min(Ast1,Ast2))
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))
        else:
            print("the structure is unsafe & redesign")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:",Ast1)
                print("Ast2:",Ast2)
                print(min(Ast1,Ast2))
                if(Ast2<Astmin):
                    print("area of steel is:",Ast2,"mm^2")
                else:
                    print("minimum area of steel required:",Astmin,"mm^2")
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))
       # print("Enter valid grade of steel!")
        break

    elif(fy==415):
        mulim=0.138*fck*b*d*d
        print("the limiting moment of resistance is:",mulim,"N.mm")
        if(mu<mulim):
            print("the structure is safe & it is under reinforced section")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:",Ast1)
                print("Ast2:",Ast2)
                print(min(Ast1,Ast2))
                if(Ast2<Astmin):
                    print("area of steel is:",Ast2,"mm^2")
                else:
                    print("minimum area of steel required:",Astmin,"mm^2")
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))
        else:
            print("the structure is unsafe & redesign")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:",Ast1)
                print("Ast2:",Ast2)
                print(min(Ast1,Ast2))
                if(Ast2<Astmin):
                    print("area of steel is:",Ast2,"mm^2")
                else:
                    print("minimum area of steel required:",Astmin,"mm^2")
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))

    elif(fy==500):
        mulim=0.133*fck*b*d*d
        print("the limiting moment of resistance is:",mulim,"N.mm")
        if(mu<mulim):
            print("the structure is safe & it is under reinforced section")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:",Ast1)
                print("Ast2:",Ast2)
                print(min(Ast1,Ast2))
                if(Ast2<Astmin):
                    print("area of steel is:",Ast2,"mm^2")
                else:
                    print("minimum area of steel required:",Astmin,"mm^2")
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))
        else:
            print("the structure is unsafe & redesign")
            a=(0.87*fy*fy)/(fck*b)
            b=-(0.87*fy*d)
            c=mu
            e=(b**2)-(4*a*c)
            f=e**0.5
            if(e<0):
                print("imaginary roots")
            else:
                Ast1=(-b+f)/(2*a)
                Ast2=(-b-f)/(2*a)
                print("Ast1:",Ast1)
                print("Ast2:",Ast2)
                print(min(Ast1,Ast2))
                ast=(3.141/4)*phi**2
                n=Ast2/ast
                print("the number of bars required is:",n,"equal to",math.ceil(n))
